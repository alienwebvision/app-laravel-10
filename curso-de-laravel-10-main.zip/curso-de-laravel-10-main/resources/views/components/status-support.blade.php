<div class="inline px-3 py-1 text-sm font-normal rounded-full text-{{$color}}-500 gap-x-2 bg-{{$color}}-100/60">
    {{ $textStatus }}
</div>
